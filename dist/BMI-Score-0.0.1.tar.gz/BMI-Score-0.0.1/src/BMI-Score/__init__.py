from bmi_score import bmi
from bmi_score import bmi_information